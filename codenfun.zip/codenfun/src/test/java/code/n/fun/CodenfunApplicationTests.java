package code.n.fun;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodenfunApplicationTests {

	@Test
	void contextLoads() {
	}

}
