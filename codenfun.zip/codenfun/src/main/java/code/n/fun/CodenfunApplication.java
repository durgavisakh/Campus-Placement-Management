package code.n.fun;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CodenfunApplication {

	public static void main(String[] args) {
		SpringApplication.run(CodenfunApplication.class, args);
	}

}
